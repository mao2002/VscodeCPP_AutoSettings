#include<bits\stdc++.h>
using namespace std;
int main(){
    cout<<"你好,世界";
    for(int i=0;i<3;i++){
        string a;
        cin>>a;
        cout<<a;
    }
}